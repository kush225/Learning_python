from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

malls = [
        {"store_name": "Adidas",
            "items": [
                        { "name": "AllStar",
                            "price" : "4000"
                            }
                ]
            }
    ]


#GET to Give data
#POST tp receive data

@app.route("/")
def starterpage():
    return render_template("index.html")


@app.route("/homepage",methods=["POST"])
def mall_data_receiver():
    request_data = request.get_json()
    new_store = { "store_name" : request_data["store_name"],
                    "items" : []
                    }
    malls.append(new_store)
    return jsonify(new_store)

@app.route("/homepage",methods=["GET"])
def mall_data_sender():
    return jsonify({"stores": malls})


@app.route("/homepage/<string:name>",methods=["GET"])
def store_data_sender(name):
    for mall in malls:
        if mall["store_name"] == name:
            return jsonify(mall)
    return jsonify({"Message" : "No store found"})

@app.route("/homepage/<string:name>/item",methods=["GET"])
def item_data_sender(name):
    for mall in malls:
        if mall["store_name"] == name:
            return jsonify({"items": mall["items"]})
    return jsonify({"Message" : "No store found"})


@app.route("/homepage/<string:name>",methods=["POST"])
def item_data_receiver(name):
    request_data = request.get_json()
    for mall in malls:
        if mall["store_name"] == name:
            new_item = { "name" : request_data["name"],
                        "price" : request_data["price"]
                        }
            mall['items'].append(new_item)
            return jsonify(mall)
    return jsonify({"Message" : "No store found"})

app.run(port=5001,debug=True)
